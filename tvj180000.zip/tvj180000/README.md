**IDE Used**: Eclipse IDE ( for JAVA )

**Student**: Thomas Johnson

**Net ID**: tvj180000

**Submission**: Project #4

**Files**:

 - RedBlackTree.java
 - Main.java
 - README.md

**Development**: This project was developed in the Eclipse IDE using the Java version JavaSE-1.8.
This program requires two arguments to be passed to it. The first is an input file i.e. ```input.txt``` and the second
is an output file i.e. ```output.txt```.

**Github Repo Link**: https://github.com/tominal/3345-DataStructures/tree/project-4
