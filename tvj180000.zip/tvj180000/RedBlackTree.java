package cs3345p4;

/**
 * 
 * @author Thomas Johnson
 * @class CS 3345
 * @section 001
 * @semester Fall 2019
 * @project #4
 * @description
 * 		The RedBlackTree class simply inserts and does not bother with deletion.
 * 		The node type of the binary search tree, Node, is protectedly nested within the class.
 *
 */

public class RedBlackTree<E extends Comparable<E>> {

	protected static class Node<E extends Comparable<E>> {
		
		protected E e;
		protected Node<E> left;
		protected Node<E> right;
		protected Node<E> parent;
		protected boolean color;
		
		public Node() {
			this(null);
		}
		
		public Node(E element) {
			this.e = element;
			left = null;
			right = null;
			parent = null;
			color = BLACK;
		}
		
		public String toString() {
			return (color == RED) ? "*" + e : "" + e;
		}
		
	}
	
	public RedBlackTree() {
		empty = new Node<E>();
		root = empty;
	}
	
	public boolean insert(E e) throws NullPointerException {
		if(e == null)
			throw new NullPointerException();
				
		Node<E> node = new Node<E>(e);
		Node<E> temp1 = empty;
				
		Node<E> pointer = root;
		
		while(pointer != empty) {
			temp1 = pointer;
			
			int compare = node.e.compareTo(pointer.e);
			
			if(compare < 0)
				pointer = pointer.left;
			else if(compare > 0)
				pointer = pointer.right;
			else
				return false;
		}
		
		node.parent = temp1;
		
		if(temp1 == empty)
			root = node;
		else if(node.e.compareTo(temp1.e) < 0)
			temp1.left = node;
		else
			temp1.right = node;
		
		node.left = empty;
		node.right = empty;
		node.color = RED;
		
		balance(node);
		
		return true;
	}
	
	public boolean contains(Comparable<E> obj) {
		Node<E> temp = new Node<E>();
		
		return (obj == null || contains(root, obj) == temp) ? false : true;
	}
	
	public String toString() {
		String temp = "";
		if(root == null)
			return "";
		else
			return preorder(root, temp).toString();
	}
	
	private Node<E> root;
	private Node<E> empty;
	private static final boolean BLACK = true;
	private static final boolean RED = false;
	
	private void balance(Node<E> node) {
		while(node.parent.color == RED) {
			if(node.parent.equals(node.parent.parent.left)) {
				Node<E> temp = node.parent.parent.right;
				
				if(temp.color == RED) {
					node.parent.color = BLACK;
					temp.color = BLACK;
					node.parent.parent.color = RED;
					node = node.parent.parent;
				} else {
					if(node.equals(node.parent.right)) {
						node = node.parent;
						
						rotateLeft(node);
					}
					
					node.parent.color = BLACK;
					node.parent.parent.color = RED;
					
					rotateRight(node.parent.parent);
				}
			} else/* if(node.parent.parent.left != null) */{
				Node<E> temp = node.parent.parent.left;
				
				if(temp.color == RED) {
					node.parent.color = BLACK;
					temp.color = BLACK;
					node.parent.parent.color = BLACK;
					node = node.parent.parent;
				} else {
					if(node.equals(node.parent.left)) {
						node = node.parent;
						
						rotateRight(node);
					}
					
					node.parent.color = BLACK;
					node.parent.parent.color = RED;

					rotateLeft(node.parent.parent);
				}
			}
		}
		
		root.color = BLACK;
	}
	
	private void rotateLeft(Node<E> node) {
		Node<E> temp1 = node.right;
		
		node.right = temp1.left;
		
		if(!temp1.left.equals(empty)) {
			temp1.left.parent = node;
		}
		
		temp1.parent = node.parent;
		
		if(node.parent.equals(empty))
			root = temp1;
		else if(node.equals(node.parent.left))
			node.parent.left = temp1;
		else
			node.parent.right = temp1;
		
		temp1.left = node;
		node.parent = temp1;
	}
	
	private void rotateRight(Node<E> node) {
		Node<E> temp1 = node.left;
		
		node.left = temp1.right;
		
		if(!temp1.right.equals(empty))
			temp1.right.parent = node;
		
		temp1.parent = node.parent;
		
		if(node.parent.equals(empty))
			root = temp1;
		else if(node.equals(node.parent.right))
			node.parent.right = temp1;
		else
			node.parent.left = temp1;
		
		temp1.right = node;
		node.parent = temp1;
	}
	
	private Node<E> contains(Node<E> node, Comparable<E> obj) {
		
		while(node != empty && !obj.equals(node.e)) {
			if(obj.compareTo(node.e) < 0)
				node = node.left;
			else
				node = node.right;
		}

		return node;
	}

	private String preorder(Node<E> node, String temp) {
		if(node != null && node.e != null) {
			temp += node.toString() + " ";
			preorder(node.left, temp);
			preorder(node.right, temp);
		}
		
		return temp;
	}
}
